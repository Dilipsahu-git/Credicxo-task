from django.urls import path, include
from .import views
from django.urls import path, include
from .views import Home, Teacher_signup, Student_signup, Data_To_Admin, Data_To_Teacher, Student_Profile, Add_item_by_teacher, add_teacher_item_by_admin, add_student_item_by_admin
from . import views

urlpatterns = [
    path('', Home.as_view(), name='homepage'),
    path('teacher_signup/', Teacher_signup.as_view(), name='teach_signup'),
    path('student_signup/', Student_signup.as_view(), name='stud_signup'),
    path('data_to_admin/', Data_To_Admin.as_view(), name='data_to_admin'),
    path('data_to_teacher/', Data_To_Teacher.as_view(), name='data_to_teach'),
    path('student_profile/', Student_Profile.as_view(), name='student_profile'), 
    path('add_item_by_teacher/', Add_item_by_teacher.as_view(), name='student_profile'),
    path('add_teacher_item_by_admin/', add_teacher_item_by_admin.as_view(), name='add_teacher_item_by_admin'),
    path('add_student_item_by_admin/', add_student_item_by_admin.as_view(), name='add_student_item_by_admin'),

     
]