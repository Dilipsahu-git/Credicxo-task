from django.shortcuts import render, HttpResponse, redirect, HttpResponseRedirect
from .models import Teacher, Student
from django.views import View
# Create your views here.


#================================Home Page=====================================
class Home(View):
    def get(self, request):
        return render(request, 'home.html')

#================================Admin view and add data of teacher and student=====================================

class Data_To_Admin(View):
    def get(self, request):
        student = Student.objects.all()
        teacher = Teacher.objects.all()
        return render(request, 'data_to_admin.html', {'teacherdata':teacher, 'studentdata':student})


#========Add teacher item by admin===========================================================

class add_teacher_item_by_admin(View):
# Form GET request
    def get(self, request):
        return render(request, 'add_teacher_item_by_admin.html')
# Form POST request
    def post(self, request):
        postData = request.POST

        firstname = postData.get('firstname')
        lastname = postData.get('lastname')
        tclass = postData.get('classteacher')
        subject = postData.get('subj')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')

        value = {
            'first_name': firstname,
            'last_name': lastname,
            'tclass': tclass,
            'subject': subject,
            'phone': phone,
            'email': email,
            'password': password
        }

        error_message = None
        teacher = Teacher(first_name=firstname, last_name=lastname, tclass=tclass, subject=subject,
                              phone=phone, email=email, password=password)

        # validation
        if not firstname:
            error_message = "First name required."
        elif len(firstname) < 3:
            error_message = "Name must be 3 character long."

        elif not lastname:
            error_message = "Last name required."
        elif len(lastname) < 3:
            error_message = "Last name must be 3 character long."

        elif not tclass:
            error_message = "Class name required."
        elif int(tclass) < 1:
            error_message = "Enter valid class."

        elif not subject:
            error_message = "Subject name required."
        elif len(subject) < 3:
            error_message = "Subject name must be 3 character long."

        elif not phone:
            error_message = "Phone required."
        elif len(phone) < 10:
            error_message = "Phone must be 10 Digit."

        elif not email:
            error_message = "Email required."
        elif len(email) < 5:
            error_message = "Email should check."

        elif not password:
            error_message = "Password required."
        elif len(password) < 5:
            error_message = "Password must be longer than 5 character."

        # saving
        if not error_message:
            teacher.save()
            return redirect('data_to_admin')

        else:
            data = {'error': error_message, 'values': value}
            return render(request, 'add_teacher_item_by_admin.html', data)



#=========Add student item by admin=============================================================

class add_student_item_by_admin(View):
# Form GET request
    def get(self, request):
        return render(request, 'add_student_item_by_admin.html')

# Form POST request
    def post(self, request):
        postData = request.POST

        firstname = postData.get('firstname')
        lastname = postData.get('lastname')
        age = postData.get('age')
        std = postData.get('std')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')

        value = {
            'first_name': firstname,
            'last_name': lastname,
            'age' : age,
            'std': std,
            'phone': phone,
            'email': email,
            'password': password
        }

        error_message = None
        student = Student(first_name=firstname, last_name=lastname, age=age, std=std,
                              phone=phone, email=email, password=password)

        # validation
        if not firstname:
            error_message = "First name required."
        elif len(firstname) < 3:
            error_message = "Name must be 3 character long."

        elif not lastname:
            error_message = "Last name required."
        elif len(lastname) < 3:
            error_message = "Last name must be 3 character long."

        elif not age:
            error_message = "Age required."
        elif int(age) < 5 or int(age) > 20:
            error_message = "Student Age is less than 5 year."

        elif not std:
            error_message = "Std required."
        elif int(std) == 0 or int(std) > 12:
            error_message = "Enter valid std."

        elif not email:
            error_message = "Email required."
        elif len(email) < 5:
            error_message = "Email should check."

        elif not password:
            error_message = "Password required."
        elif len(password) < 5:
            error_message = "Password must be longer than 5 character."

        # saving credential in database
        if not error_message:
            student.save()
            return redirect('data_to_admin')

        else:
            data = {'error': error_message, 'values': value}
            return render(request, 'add_student_item_by_admin.html', data)




#================================Teacher-Signup and Student data to teacher=====================================

# Form GET request
class Teacher_signup(View):
    def get(self, request):
        return render(request, 'teacher_signup.html')

# Form POST request
    def post(self, request):
        postData = request.POST

        firstname = postData.get('firstname')
        lastname = postData.get('lastname')
        tclass = postData.get('classteacher')
        subject = postData.get('subj')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')

        value = {
            'first_name': firstname,
            'last_name': lastname,
            'tclass': tclass,
            'subject': subject,
            'phone': phone,
            'email': email,
            'password': password
        }

        error_message = None
        teacher = Teacher(first_name=firstname, last_name=lastname, tclass=tclass, subject=subject,
                              phone=phone, email=email, password=password)

        # validation
        if not firstname:
            error_message = "First name required."
        elif len(firstname) < 3:
            error_message = "Name must be 3 character long."

        elif not lastname:
            error_message = "Last name required."
        elif len(lastname) < 3:
            error_message = "Last name must be 3 character long."

        elif not tclass:
            error_message = "Class name required."
        elif int(tclass) < 1:
            error_message = "Enter valid class."

        elif not subject:
            error_message = "Subject name required."
        elif len(subject) < 3:
            error_message = "Subject name must be 3 character long."

        elif not phone:
            error_message = "Phone required."
        elif len(phone) < 10:
            error_message = "Phone must be 10 Digit."

        elif not email:
            error_message = "Email required."
        elif len(email) < 5:
            error_message = "Email should check."

        elif not password:
            error_message = "Password required."
        elif len(password) < 5:
            error_message = "Password must be longer than 5 character."

        # saving
        if not error_message:
            teacher.save()
            return redirect('viewdatatoteach')

        else:
            data = {'error': error_message, 'values': value}
            return render(request, 'student_signup.html', data)



# teacher view student data
class Data_To_Teacher(View):
    def get(self, request):
        student = Student.objects.all()
        return render(request, 'data_to_teacher.html', {'studentdata':student})

#=================================Student-Signup and Student profile to student==================================================================

class Student_signup(View):
# Form GET request
    def get(self, request):
        return render(request, 'student_signup.html')

# Form POST request
    def post(self, request):
        postData = request.POST

        firstname = postData.get('firstname')
        lastname = postData.get('lastname')
        age = postData.get('age')
        std = postData.get('std')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')

        value = {
            'first_name': firstname,
            'last_name': lastname,
            'age' : age,
            'std': std,
            'phone': phone,
            'email': email,
            'password': password
        }

        error_message = None
        student = Student(first_name=firstname, last_name=lastname, age=age, std=std,
                              phone=phone, email=email, password=password)

        # validation
        if not firstname:
            error_message = "First name required."
        elif len(firstname) < 3:
            error_message = "Name must be 3 character long."

        elif not lastname:
            error_message = "Last name required."
        elif len(lastname) < 3:
            error_message = "Last name must be 3 character long."

        elif not age:
            error_message = "Age required."
        elif int(age) < 5 or int(age) > 20:
            error_message = "Student Age is less than 5 year."

        elif not std:
            error_message = "Std required."
        elif int(std) == 0 or int(std) > 12:
            error_message = "Enter valid std."

        elif not email:
            error_message = "Email required."
        elif len(email) < 5:
            error_message = "Email should check."

        elif not password:
            error_message = "Password required."
        elif len(password) < 5:
            error_message = "Password must be longer than 5 character."

        # saving credential in database
        if not error_message:
            student.save()
            return redirect('studentprofile')

        else:
            data = {'error': error_message, 'values': value}
            return render(request, 'signupstudent.html', data)


# Student check profile
class Student_Profile(View):
# Form GET request
    def get(self, request):
        student = Student.objects.all() # fectching data from database
        return render(request, 'student_profile.html', {'studentdata':student})

#==========================================Add item by teacher=================================================================

class Add_item_by_teacher(View):
# Form GET request
    def get(self, request):
        return render(request, 'add_item_by_teacher.html')
# Form POST request
    def post(self, request):
        postData = request.POST

        firstname = postData.get('firstname')
        lastname = postData.get('lastname')
        age = postData.get('age')
        std = postData.get('std')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')

        value = {
            'first_name': firstname,
            'last_name': lastname,
            'age' : age,
            'std': std,
            'phone': phone,
            'email': email,
            'password': password
        }

        error_message = None
        student = Student(first_name=firstname, last_name=lastname, age=age, std=std,
                              phone=phone, email=email, password=password)

        # validation
        if not firstname:
            error_message = "First name required."
        elif len(firstname) < 3:
            error_message = "Name must be 3 character long."

        elif not lastname:
            error_message = "Last name required."
        elif len(lastname) < 3:
            error_message = "Last name must be 3 character long."

        elif not age:
            error_message = "Age required."
        elif int(age) < 5 or int(age) > 20:
            error_message = "Student Age is less than 5 year."

        elif not std:
            error_message = "Std required."
        elif int(std) == 0 or int(std) > 12:
            error_message = "Enter valid std."

        elif not email:
            error_message = "Email required."
        elif len(email) < 5:
            error_message = "Email should check."

        elif not password:
            error_message = "Password required."
        elif len(password) < 5:
            error_message = "Password must be longer than 5 character."

        # saving credential in database
        if not error_message:
            student.save()
            return redirect('data_to_teach')

        else:
            data = {'error': error_message, 'values': value}
            return render(request, 'add_item_by_teacher.html', data)

